package com.routemax.pro;

import android.Manifest;
import android.content.Intent;
import android.os.Handler;
import android.os.Looper;

import com.getcapacitor.JSObject;
import com.getcapacitor.PermissionState;
import com.getcapacitor.Plugin;
import com.getcapacitor.PluginCall;
import com.getcapacitor.PluginMethod;
import com.getcapacitor.annotation.CapacitorPlugin;
import com.getcapacitor.annotation.Permission;
import com.getcapacitor.annotation.PermissionCallback;

import java.lang.ref.WeakReference;

/**
 * Capacitor bridge for the native live camera coach.
 *
 * JS API (via registerPlugin("LiveCamera")):
 *   await LiveCamera.startPreview({ exercise: "push-ups", autoWatch: true, intervalMs: 4000 })
 *   await LiveCamera.stopPreview()
 *   await LiveCamera.showStatus({ text: "Rep 3/10!", reps: "3/10" })
 *   LiveCamera.addListener("frameCaptured", ({ imageBase64 }) => ...)
 *   LiveCamera.addListener("previewClosed", () => ...)
 */
@CapacitorPlugin(
        name = "LiveCamera",
        permissions = {
                @Permission(strings = {Manifest.permission.CAMERA}, alias = "camera")
        }
)
public class LiveCameraPlugin extends Plugin {

    private static WeakReference<LiveCameraPlugin> instance = new WeakReference<>(null);
    private static WeakReference<LiveCameraActivity> activityRef = new WeakReference<>(null);

    @Override
    public void load() {
        instance = new WeakReference<>(this);
    }

    @PluginMethod
    public void startPreview(PluginCall call) {
        if (getPermissionState("camera") != PermissionState.GRANTED) {
            requestPermissionForAlias("camera", call, "cameraPermCallback");
        } else {
            launch(call);
        }
    }

    @PermissionCallback
    private void cameraPermCallback(PluginCall call) {
        if (getPermissionState("camera") == PermissionState.GRANTED) {
            launch(call);
        } else {
            call.reject("Camera permission denied");
        }
    }

    private void launch(PluginCall call) {
        String exercise = call.getString("exercise", "workout");
        boolean autoWatch = call.getBoolean("autoWatch", false);
        long intervalMs = call.getLong("intervalMs", 4000L);

        Intent i = new Intent(getContext(), LiveCameraActivity.class);
        i.putExtra(LiveCameraActivity.EXTRA_EXERCISE, exercise);
        i.putExtra(LiveCameraActivity.EXTRA_AUTO_WATCH, autoWatch);
        i.putExtra(LiveCameraActivity.EXTRA_INTERVAL_MS, intervalMs);
        i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
        getContext().startActivity(i);
        call.resolve();
    }

    @PluginMethod
    public void stopPreview(PluginCall call) {
        LiveCameraActivity a = activityRef.get();
        if (a != null) {
            a.runOnUiThread(a::finish);
        }
        call.resolve();
    }

    @PluginMethod
    public void showStatus(PluginCall call) {
        LiveCameraActivity a = activityRef.get();
        if (a != null) {
            a.showStatus(call.getString("text"), call.getString("reps"));
        }
        call.resolve();
    }

    /** Called by LiveCameraActivity when it starts (so we can reach it). */
    static void onActivityStarted(LiveCameraActivity activity) {
        activityRef = new WeakReference<>(activity);
    }

    /** Called by LiveCameraActivity with each captured frame (base64 JPEG). */
    static void onFrame(String base64) {
        LiveCameraPlugin p = instance.get();
        if (p == null) return;
        JSObject ret = new JSObject();
        ret.put("imageBase64", base64);
        new Handler(Looper.getMainLooper()).post(() ->
                p.notifyListeners("frameCaptured", ret));
    }

    /** Called by LiveCameraActivity on pause/destroy. */
    static void onActivityClosed() {
        activityRef.clear();
        LiveCameraPlugin p = instance.get();
        if (p == null) return;
        new Handler(Looper.getMainLooper()).post(() ->
                p.notifyListeners("previewClosed", new JSObject()));
    }
}
