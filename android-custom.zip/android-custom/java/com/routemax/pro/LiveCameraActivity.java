package com.routemax.pro;

import android.Manifest;
import android.content.Context;
import android.content.pm.PackageManager;
import android.graphics.ImageFormat;
import android.graphics.SurfaceTexture;
import android.hardware.camera2.CameraAccessException;
import android.hardware.camera2.CameraCaptureSession;
import android.hardware.camera2.CameraCharacteristics;
import android.hardware.camera2.CameraDevice;
import android.hardware.camera2.CameraManager;
import android.hardware.camera2.CaptureRequest;
import android.media.Image;
import android.media.ImageReader;
import android.os.Bundle;
import android.os.Handler;
import android.os.HandlerThread;
import android.util.Base64;
import android.util.Size;
import android.view.Gravity;
import android.view.Surface;
import android.view.TextureView;
import android.view.View;
import android.view.ViewGroup;
import android.widget.FrameLayout;
import android.widget.ImageButton;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;

import java.io.ByteArrayOutputStream;
import java.nio.ByteBuffer;
import java.util.Arrays;

/**
 * Full-screen native camera preview for the RouteMax workout coach.
 * Draws the camera preview OUTSIDE the WebView as a native Activity,
 * so live video never touches the WebView compositor (which black-screens).
 *
 * Modes:
 *  - Manual: user taps the shutter button to capture a frame.
 *  - Auto-watch: captures a frame every AUTO_MS for continuous AI coaching.
 *
 * Frames are delivered as JPEG base64 via LiveCameraPlugin.onFrame(base64).
 */
public class LiveCameraActivity extends AppCompatActivity {

    public static final String EXTRA_EXERCISE = "exercise";
    public static final String EXTRA_AUTO_WATCH = "autoWatch";
    public static final String EXTRA_INTERVAL_MS = "intervalMs";

    private static final long DEFAULT_INTERVAL_MS = 4000;
    private static final int PREVIEW_W = 1280;
    private static final int PREVIEW_H = 720;

    private TextureView textureView;
    private TextView statusText;
    private TextView repText;
    private ImageButton shutterBtn;

    private CameraDevice cameraDevice;
    private CameraCaptureSession captureSession;
    private CaptureRequest.Builder previewRequestBuilder;
    private ImageReader imageReader;

    private HandlerThread bgThread;
    private Handler bgHandler;
    private Handler autoHandler;
    private Runnable autoRunnable;

    private String exercise = "workout";
    private boolean autoWatch = false;
    private long intervalMs = DEFAULT_INTERVAL_MS;
    private boolean capturing = false;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        exercise = getIntent().getStringExtra(EXTRA_EXERCISE);
        if (exercise == null) exercise = "workout";
        autoWatch = getIntent().getBooleanExtra(EXTRA_AUTO_WATCH, false);
        intervalMs = getIntent().getLongExtra(EXTRA_INTERVAL_MS, DEFAULT_INTERVAL_MS);

        buildUi();
        startBackgroundThread();

        LiveCameraPlugin.onActivityStarted(this);

        if (ActivityCompat.checkSelfPermission(this, Manifest.permission.CAMERA)
                != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(this, new String[]{Manifest.permission.CAMERA}, 100);
        } else {
            openCamera();
        }
    }

    private void buildUi() {
        FrameLayout root = new FrameLayout(this);
        root.setLayoutParams(new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));
        root.setBackgroundColor(0xFF000000);

        textureView = new TextureView(this);
        textureView.setLayoutParams(new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));
        textureView.setSurfaceTextureListener(surfaceListener);
        root.addView(textureView);

        // Top bar: exercise name + rep count + close
        LinearLayout topBar = new LinearLayout(this);
        topBar.setOrientation(LinearLayout.HORIZONTAL);
        topBar.setGravity(Gravity.CENTER_VERTICAL);
        FrameLayout.LayoutParams topLp = new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        topLp.gravity = Gravity.TOP;
        topBar.setLayoutParams(topLp);
        int pad = dp(12);
        topBar.setPadding(pad, pad * 2, pad, pad);
        topBar.setBackgroundColor(0x99000000);

        TextView title = new TextView(this);
        title.setText("\uD83D\uDCF7 " + exercise + (autoWatch ? " · watching" : ""));
        title.setTextColor(0xFFFFFFFF);
        title.setTextSize(15);
        title.setTypeface(null, android.graphics.Typeface.BOLD);
        LinearLayout.LayoutParams titleLp = new LinearLayout.LayoutParams(0,
                ViewGroup.LayoutParams.WRAP_CONTENT, 1f);
        title.setLayoutParams(titleLp);
        topBar.addView(title);

        repText = new TextView(this);
        repText.setText("");
        repText.setTextColor(0xFFFFD54F);
        repText.setTextSize(15);
        repText.setTypeface(null, android.graphics.Typeface.BOLD);
        repText.setPadding(dp(8), 0, dp(8), 0);
        topBar.addView(repText);

        ImageButton closeBtn = new ImageButton(this);
        closeBtn.setImageResource(android.R.drawable.ic_menu_close_clear_cancel);
        closeBtn.setBackgroundColor(0x00000000);
        closeBtn.setColorFilter(0xFFFFFFFF);
        closeBtn.setOnClickListener(v -> finish());
        topBar.addView(closeBtn);
        root.addView(topBar);

        // Status line (AI feedback)
        statusText = new TextView(this);
        statusText.setText(autoWatch ? "Coach is watching… hold your position" : "Tap the shutter when you're in position");
        statusText.setTextColor(0xFFFFFFFF);
        statusText.setTextSize(13);
        statusText.setGravity(Gravity.CENTER);
        statusText.setPadding(pad, dp(8), pad, dp(8));
        statusText.setBackgroundColor(0x99000000);
        FrameLayout.LayoutParams statusLp = new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        statusLp.gravity = Gravity.BOTTOM;
        statusLp.bottomMargin = dp(96);
        statusText.setLayoutParams(statusLp);
        root.addView(statusText);

        // Shutter button
        shutterBtn = new ImageButton(this);
        shutterBtn.setImageResource(android.R.drawable.ic_menu_camera);
        shutterBtn.setBackgroundColor(0xFF009688);
        shutterBtn.setColorFilter(0xFFFFFFFF);
        int shutterSize = dp(72);
        FrameLayout.LayoutParams shutterLp = new FrameLayout.LayoutParams(shutterSize, shutterSize);
        shutterLp.gravity = Gravity.BOTTOM | Gravity.CENTER_HORIZONTAL;
        shutterLp.bottomMargin = dp(16);
        shutterBtn.setLayoutParams(shutterLp);
        shutterBtn.setOnClickListener(v -> captureFrame());
        root.addView(shutterBtn);

        setContentView(root);
    }

    private int dp(int d) {
        return (int) (d * getResources().getDisplayMetrics().density);
    }

    // ---------- Camera2 ----------

    private final TextureView.SurfaceTextureListener surfaceListener =
            new TextureView.SurfaceTextureListener() {
                @Override public void onSurfaceTextureAvailable(@NonNull SurfaceTexture st, int w, int h) { openCamera(); }
                @Override public void onSurfaceTextureSizeChanged(@NonNull SurfaceTexture st, int w, int h) {}
                @Override public boolean onSurfaceTextureDestroyed(@NonNull SurfaceTexture st) { return true; }
                @Override public void onSurfaceTextureUpdated(@NonNull SurfaceTexture st) {}
            };

    private final CameraDevice.StateCallback deviceCallback = new CameraDevice.StateCallback() {
        @Override public void onOpened(@NonNull CameraDevice camera) {
            cameraDevice = camera;
            startPreviewSession();
        }
        @Override public void onDisconnected(@NonNull CameraDevice camera) { closeCamera(); }
        @Override public void onError(@NonNull CameraDevice camera, int error) {
            closeCamera();
            runOnUiThread(() -> {
                Toast.makeText(LiveCameraActivity.this, "Camera error — closing", Toast.LENGTH_SHORT).show();
                finish();
            });
        }
    };

    private void openCamera() {
        if (cameraDevice != null) return;
        CameraManager mgr = (CameraManager) getSystemService(Context.CAMERA_SERVICE);
        try {
            String camId = null;
            for (String id : mgr.getCameraIdList()) {
                CameraCharacteristics c = mgr.getCameraCharacteristics(id);
                Integer facing = c.get(CameraCharacteristics.LENS_FACING);
                if (facing != null && facing == CameraCharacteristics.LENS_FACING_BACK) { camId = id; break; }
            }
            if (camId == null) camId = mgr.getCameraIdList()[0];
            if (ActivityCompat.checkSelfPermission(this, Manifest.permission.CAMERA)
                    != PackageManager.PERMISSION_GRANTED) return;
            mgr.openCamera(camId, deviceCallback, bgHandler);
        } catch (CameraAccessException e) {
            runOnUiThread(() -> {
                Toast.makeText(this, "Can't open camera", Toast.LENGTH_SHORT).show();
                finish();
            });
        }
    }

    private void startPreviewSession() {
        try {
            SurfaceTexture st = textureView.getSurfaceTexture();
            if (st == null || cameraDevice == null) return;
            st.setDefaultBufferSize(PREVIEW_W, PREVIEW_H);
            Surface previewSurface = new Surface(st);

            imageReader = ImageReader.newInstance(PREVIEW_W, PREVIEW_H, ImageFormat.JPEG, 2);
            imageReader.setOnImageAvailableListener(reader -> {
                Image img = null;
                try {
                    img = reader.acquireLatestImage();
                    if (img != null && capturing) {
                        capturing = false;
                        String b64 = imageToBase64(img);
                        if (b64 != null) LiveCameraPlugin.onFrame(b64);
                    }
                } finally {
                    if (img != null) img.close();
                }
            }, bgHandler);

            previewRequestBuilder = cameraDevice.createCaptureRequest(CameraDevice.TEMPLATE_PREVIEW);
            previewRequestBuilder.addTarget(previewSurface);
            previewRequestBuilder.addTarget(imageReader.getSurface());

            cameraDevice.createCaptureSession(
                    Arrays.asList(previewSurface, imageReader.getSurface()),
                    new CameraCaptureSession.StateCallback() {
                        @Override public void onConfigured(@NonNull CameraCaptureSession session) {
                            captureSession = session;
                            try {
                                previewRequestBuilder.set(CaptureRequest.CONTROL_AF_MODE,
                                        CaptureRequest.CONTROL_AF_MODE_CONTINUOUS_PICTURE);
                                session.setRepeatingRequest(previewRequestBuilder.build(), null, bgHandler);
                                if (autoWatch) startAutoWatch();
                            } catch (CameraAccessException e) { /* ignore */ }
                        }
                        @Override public void onConfigureFailed(@NonNull CameraCaptureSession session) {
                            runOnUiThread(() -> {
                                Toast.makeText(LiveCameraActivity.this, "Camera preview failed", Toast.LENGTH_SHORT).show();
                                finish();
                            });
                        }
                    }, bgHandler);
        } catch (CameraAccessException e) {
            finish();
        }
    }

    /** Capture one still frame; delivered to JS via LiveCameraPlugin.onFrame. */
    private void captureFrame() {
        if (cameraDevice == null || capturing) return;
        capturing = true;
        runOnUiThread(() -> {
            statusText.setText("Captured — coach is looking…");
            shutterBtn.setEnabled(false);
            shutterBtn.postDelayed(() -> shutterBtn.setEnabled(true), 1500);
        });
        try {
            CaptureRequest.Builder snapBuilder =
                    cameraDevice.createCaptureRequest(CameraDevice.TEMPLATE_STILL_CAPTURE);
            snapBuilder.addTarget(imageReader.getSurface());
            snapBuilder.set(CaptureRequest.CONTROL_AF_MODE,
                    CaptureRequest.CONTROL_AF_MODE_CONTINUOUS_PICTURE);
            captureSession.capture(snapBuilder.build(), null, bgHandler);
        } catch (CameraAccessException e) {
            capturing = false;
        }
    }

    private void startAutoWatch() {
        autoHandler = new Handler(getMainLooper());
        autoRunnable = new Runnable() {
            @Override public void run() {
                if (!isFinishing() && !isDestroyed()) {
                    captureFrame();
                    autoHandler.postDelayed(this, intervalMs);
                }
            }
        };
        // First capture after a short settle delay so exposure/focus lock in
        autoHandler.postDelayed(autoRunnable, 2500);
    }

    private void stopAutoWatch() {
        if (autoHandler != null && autoRunnable != null) autoHandler.removeCallbacks(autoRunnable);
    }

    private String imageToBase64(Image image) {
        try {
            ByteBuffer buf = image.getPlanes()[0].getBuffer();
            byte[] bytes = new byte[buf.remaining()];
            buf.get(bytes);
            return Base64.encodeToString(bytes, Base64.NO_WRAP);
        } catch (Exception e) {
            return null;
        }
    }

    /** Called by the plugin when JS reports the rep count / AI feedback. */
    public void showStatus(final String text, final String reps) {
        runOnUiThread(() -> {
            if (text != null) statusText.setText(text);
            if (reps != null) repText.setText(reps);
        });
    }

    // ---------- Lifecycle ----------

    private void startBackgroundThread() {
        bgThread = new HandlerThread("LiveCameraBg");
        bgThread.start();
        bgHandler = new Handler(bgThread.getLooper());
    }

    private void stopBackgroundThread() {
        if (bgThread != null) {
            bgThread.quitSafely();
            try { bgThread.join(); } catch (InterruptedException ignored) {}
            bgThread = null;
            bgHandler = null;
        }
    }

    private void closeCamera() {
        stopAutoWatch();
        try {
            if (captureSession != null) { captureSession.close(); captureSession = null; }
            if (cameraDevice != null) { cameraDevice.close(); cameraDevice = null; }
            if (imageReader != null) { imageReader.close(); imageReader = null; }
        } catch (Exception ignored) {}
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions,
                                           @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == 100 && grantResults.length > 0
                && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
            openCamera();
        } else {
            Toast.makeText(this, "Camera permission needed for the coach", Toast.LENGTH_LONG).show();
            finish();
        }
    }

    @Override
    protected void onPause() {
        closeCamera();
        LiveCameraPlugin.onActivityClosed();
        super.onPause();
    }

    @Override
    protected void onDestroy() {
        closeCamera();
        stopBackgroundThread();
        LiveCameraPlugin.onActivityClosed();
        super.onDestroy();
    }
}
