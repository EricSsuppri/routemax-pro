package com.routemax.pro;

import android.Manifest;
import android.content.Intent;
import android.os.Build;
import android.os.Handler;
import android.os.Looper;

import androidx.core.content.ContextCompat;

import com.getcapacitor.JSObject;
import com.getcapacitor.PermissionState;
import com.getcapacitor.Plugin;
import com.getcapacitor.PluginCall;
import com.getcapacitor.PluginMethod;
import com.getcapacitor.annotation.CapacitorPlugin;
import com.getcapacitor.annotation.Permission;
import com.getcapacitor.annotation.PermissionCallback;

/**
 * Capacitor bridge for the screenshot watcher.
 * JS: ScreenshotWatcher.startWatching() / stopWatching()
 * Event: "screenshotDetected" -> { imageBase64 }
 */
@CapacitorPlugin(
        name = "ScreenshotWatcher",
        permissions = {
                @Permission(strings = {Manifest.permission.READ_MEDIA_IMAGES}, alias = "mediaImages"),
                @Permission(strings = {Manifest.permission.READ_EXTERNAL_STORAGE}, alias = "mediaLegacy")
        }
)
public class ScreenshotWatcherPlugin extends Plugin {

    private static final String ALIAS_IMAGES = "mediaImages";
    private static final String ALIAS_LEGACY = "mediaLegacy";

    @PluginMethod
    public void startWatching(PluginCall call) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            requestPermissionForAlias(ALIAS_IMAGES, call, "permissionCallback");
        } else {
            requestPermissionForAlias(ALIAS_LEGACY, call, "permissionCallback");
        }
    }

    @PermissionCallback
    private void permissionCallback(PluginCall call) {
        boolean granted =
                getPermissionState(ALIAS_IMAGES) == PermissionState.GRANTED
                        || getPermissionState(ALIAS_LEGACY) == PermissionState.GRANTED;
        if (!granted) {
            call.reject("Photo access was denied");
            return;
        }
        ScreenshotWatcherService.listener = base64 -> {
            JSObject ret = new JSObject();
            ret.put("imageBase64", base64);
            new Handler(Looper.getMainLooper()).post(() ->
                    notifyListeners("screenshotDetected", ret));
        };
        Intent intent = new Intent(getContext(), ScreenshotWatcherService.class);
        ContextCompat.startForegroundService(getContext(), intent);
        call.resolve();
    }

    @PluginMethod
    public void stopWatching(PluginCall call) {
        ScreenshotWatcherService.listener = null;
        try {
            getContext().stopService(new Intent(getContext(), ScreenshotWatcherService.class));
        } catch (Exception ignored) {}
        call.resolve();
    }
}
