package com.routemax.pro;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.Service;
import android.content.ContentResolver;
import android.content.Context;
import android.content.Intent;
import android.content.pm.ServiceInfo;
import android.database.ContentObserver;
import android.database.Cursor;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.net.Uri;
import android.os.Build;
import android.os.Handler;
import android.os.HandlerThread;
import android.os.IBinder;
import android.provider.MediaStore;
import android.util.Base64;

import androidx.core.app.NotificationCompat;

import java.io.ByteArrayOutputStream;
import java.io.InputStream;

/**
 * Foreground service that watches MediaStore for new screenshots and
 * hands them to the JS layer as downscaled base64 JPEGs.
 */
public class ScreenshotWatcherService extends Service {
    private static final String CHANNEL_ID = "rm_screenshot_watcher";
    private static final int NOTIF_ID = 4242;

    public interface Listener {
        void onScreenshot(String base64Jpeg);
    }

    public static volatile Listener listener;

    private HandlerThread observerThread;
    private ContentObserver observer;
    private long lastSeenId = -1L;

    @Override
    public IBinder onBind(Intent intent) {
        return null;
    }

    @Override
    public void onCreate() {
        super.onCreate();
        observerThread = new HandlerThread("screenshot-observer");
        observerThread.start();
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        Notification notif = buildNotification();
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            startForeground(NOTIF_ID, notif, ServiceInfo.FOREGROUND_SERVICE_TYPE_DATA_SYNC);
        } else {
            startForeground(NOTIF_ID, notif);
        }
        if (observer == null) {
            observer = new ContentObserver(new Handler(observerThread.getLooper())) {
                @Override
                public void onChange(boolean selfChange, Uri uri) {
                    checkLatestImage();
                }
            };
            getContentResolver().registerContentObserver(
                    MediaStore.Images.Media.EXTERNAL_CONTENT_URI, true, observer);
        }
        return START_STICKY;
    }

    @Override
    public void onDestroy() {
        if (observer != null) {
            try {
                getContentResolver().unregisterContentObserver(observer);
            } catch (Exception ignored) {}
            observer = null;
        }
        if (observerThread != null) {
            observerThread.quitSafely();
            observerThread = null;
        }
        super.onDestroy();
    }

    private Notification buildNotification() {
        NotificationManager nm =
                (NotificationManager) getSystemService(Context.NOTIFICATION_SERVICE);
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O && nm != null) {
            NotificationChannel ch = new NotificationChannel(
                    CHANNEL_ID, "Offer screenshot watcher",
                    NotificationManager.IMPORTANCE_LOW);
            nm.createNotificationChannel(ch);
        }
        return new NotificationCompat.Builder(this, CHANNEL_ID)
                .setContentTitle("RouteMax Pro is watching")
                .setContentText("New offer screenshots will be scanned automatically")
                .setSmallIcon(android.R.drawable.ic_menu_camera)
                .setOngoing(true)
                .build();
    }

    private void checkLatestImage() {
        Listener l = listener;
        if (l == null) return;
        try {
            ContentResolver cr = getContentResolver();
            Uri base = MediaStore.Images.Media.EXTERNAL_CONTENT_URI;
            String[] proj = new String[]{
                    MediaStore.Images.Media._ID,
                    MediaStore.Images.Media.DISPLAY_NAME,
                    MediaStore.Images.Media.RELATIVE_PATH
            };
            try (Cursor c = cr.query(base, proj, null, null,
                    MediaStore.Images.Media.DATE_ADDED + " DESC")) {
                if (c == null || !c.moveToFirst()) return;
                long id = c.getLong(0);
                if (id == lastSeenId) return;
                lastSeenId = id;
                String name = c.getString(1);
                String relPath = c.getString(2);
                String hay = ((name == null ? "" : name) + " "
                        + (relPath == null ? "" : relPath)).toLowerCase();
                if (!hay.contains("screenshot")) return;
                Uri uri = Uri.withAppendedPath(base, Long.toString(id));
                String b64 = downscaleToBase64(uri);
                if (b64 != null) l.onScreenshot(b64);
            }
        } catch (Exception ignored) {
            // never crash the service on a bad image
        }
    }

    private String downscaleToBase64(Uri uri) {
        try {
            BitmapFactory.Options bounds = new BitmapFactory.Options();
            bounds.inJustDecodeBounds = true;
            try (InputStream in = getContentResolver().openInputStream(uri)) {
                if (in == null) return null;
                BitmapFactory.decodeStream(in, null, bounds);
            }
            int w = bounds.outWidth, h = bounds.outHeight;
            if (w <= 0 || h <= 0) return null;
            int sample = 1;
            while (w / sample > 900 || h / sample > 900) sample *= 2;
            BitmapFactory.Options opts = new BitmapFactory.Options();
            opts.inSampleSize = sample;
            Bitmap bmp;
            try (InputStream in2 = getContentResolver().openInputStream(uri)) {
                if (in2 == null) return null;
                bmp = BitmapFactory.decodeStream(in2, null, opts);
            }
            if (bmp == null) return null;
            ByteArrayOutputStream baos = new ByteArrayOutputStream();
            bmp.compress(Bitmap.CompressFormat.JPEG, 70, baos);
            bmp.recycle();
            return Base64.encodeToString(baos.toByteArray(), Base64.NO_WRAP);
        } catch (Exception e) {
            return null;
        }
    }
}
